"use client"

import Link from "next/link"
import { ShoppingCart, User, LogOut, Menu, X } from "lucide-react"
import { useState } from "react"

interface NavigationProps {
  customer: any
  onLogout: () => void
}

export function Navigation({ customer, onLogout }: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <nav className="sticky top-0 z-50 bg-white border-b-2 border-slate-200 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <Link href="/" className="text-2xl font-bold text-primary">
            زمزم
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex gap-6">
            <Link href="/" className="font-semibold text-slate-700 hover:text-primary transition-colors">
              خانه
            </Link>
            <Link href="/#products" className="font-semibold text-slate-700 hover:text-primary transition-colors">
              محصولات
            </Link>
            <Link href="/contact" className="font-semibold text-slate-700 hover:text-primary transition-colors">
              تماس با ما
            </Link>
            <Link href="/admin" className="font-semibold text-slate-700 hover:text-primary transition-colors">
              مدیریت
            </Link>
          </div>
        </div>

        {/* Desktop Actions */}
        <div className="hidden md:flex items-center gap-4">
          {customer ? (
            <>
              <span className="text-slate-700 font-semibold">خوش‌آمدید {customer.name}</span>
              <Link
                href="/checkout"
                className="flex items-center gap-2 bg-accent text-white px-4 py-2 rounded-lg hover:opacity-90 transition-opacity"
              >
                <ShoppingCart size={20} />
                <span>سفارش</span>
              </Link>
              <button
                onClick={onLogout}
                className="flex items-center gap-2 text-slate-700 hover:text-primary transition-colors"
              >
                <LogOut size={20} />
              </button>
            </>
          ) : (
            <>
              <Link
                href="/login"
                className="flex items-center gap-2 text-accent font-semibold hover:opacity-80 transition-opacity"
              >
                <User size={20} />
                <span>ورود</span>
              </Link>
              <Link
                href="/register"
                className="flex items-center gap-2 text-primary font-semibold hover:opacity-80 transition-opacity"
              >
                <User size={20} />
                <span>ثبت‌نام</span>
              </Link>
              <Link
                href="/checkout"
                className="flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg hover:opacity-90 transition-opacity"
              >
                <ShoppingCart size={20} />
                <span>سفارش</span>
              </Link>
            </>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-slate-200 p-4 flex flex-col gap-4">
          <Link href="/" className="font-semibold text-slate-700 hover:text-primary transition-colors">
            خانه
          </Link>
          <Link href="/#products" className="font-semibold text-slate-700 hover:text-primary transition-colors">
            محصولات
          </Link>
          <Link href="/contact" className="font-semibold text-slate-700 hover:text-primary transition-colors">
            تماس با ما
          </Link>
          <Link href="/admin" className="font-semibold text-slate-700 hover:text-primary transition-colors">
            مدیریت
          </Link>

          {customer ? (
            <>
              <span className="text-slate-700 font-semibold">خوش‌آمدید {customer.name}</span>
              <Link
                href="/checkout"
                className="flex items-center gap-2 bg-accent text-white px-4 py-2 rounded-lg hover:opacity-90 transition-opacity"
              >
                <ShoppingCart size={20} />
                <span>سفارش</span>
              </Link>
              <button
                onClick={onLogout}
                className="flex items-center gap-2 text-slate-700 hover:text-primary transition-colors w-full"
              >
                <LogOut size={20} />
                <span>خروج</span>
              </button>
            </>
          ) : (
            <>
              <Link
                href="/login"
                className="flex items-center gap-2 text-accent font-semibold hover:opacity-80 transition-opacity"
              >
                <User size={20} />
                <span>ورود</span>
              </Link>
              <Link
                href="/register"
                className="flex items-center gap-2 text-primary font-semibold hover:opacity-80 transition-opacity"
              >
                <User size={20} />
                <span>ثبت‌نام</span>
              </Link>
              <Link
                href="/checkout"
                className="flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg hover:opacity-90 transition-opacity"
              >
                <ShoppingCart size={20} />
                <span>سفارش</span>
              </Link>
            </>
          )}
        </div>
      )}
    </nav>
  )
}
