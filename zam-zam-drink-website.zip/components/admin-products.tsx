"use client"

import { useState } from "react"
import { Edit2, Trash2, Plus } from "lucide-react"

interface Product {
  id: number
  name: string
  price: number
  stock: number
}

export function AdminProducts() {
  const [products, setProducts] = useState<Product[]>([
    { id: 1, name: "نوشابه گازدار کولا", price: 15000, stock: 150 },
    { id: 2, name: "نوشابه گازدار پرتقالی", price: 15000, stock: 120 },
    { id: 3, name: "نوشابه گازدار لیمو زمزم", price: 15000, stock: 140 },
  ])
  const [editing, setEditing] = useState<Product | null>(null)
  const [isAdding, setIsAdding] = useState(false)
  const [formData, setFormData] = useState({ name: "", price: "", stock: "" })

  const handleEdit = (product: Product) => {
    setEditing(product)
    setFormData({ name: product.name, price: product.price.toString(), stock: product.stock.toString() })
  }

  const handleSave = () => {
    if (!formData.name || !formData.price || !formData.stock) {
      alert("لطفاً تمام فیلدها را پر کنید")
      return
    }

    if (editing) {
      const updated = products.map((p) =>
        p.id === editing.id
          ? {
              ...p,
              name: formData.name,
              price: Number.parseInt(formData.price),
              stock: Number.parseInt(formData.stock),
            }
          : p,
      )
      setProducts(updated)
    } else {
      const newProduct = {
        id: Math.max(...products.map((p) => p.id)) + 1,
        name: formData.name,
        price: Number.parseInt(formData.price),
        stock: Number.parseInt(formData.stock),
      }
      setProducts([...products, newProduct])
    }

    setEditing(null)
    setIsAdding(false)
    setFormData({ name: "", price: "", stock: "" })
  }

  const handleDelete = (id: number) => {
    if (confirm("آیا مطمئن هستید؟")) {
      setProducts(products.filter((p) => p.id !== id))
    }
  }

  return (
    <div className="bg-white rounded-lg shadow border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-slate-200 flex justify-between items-center">
        <h2 className="text-2xl font-bold text-primary text-right flex-1">لیست محصولات</h2>
        <button
          onClick={() => {
            setIsAdding(true)
            setFormData({ name: "", price: "", stock: "" })
          }}
          className="bg-secondary hover:bg-secondary/90 text-white font-bold py-2 px-4 rounded-lg flex items-center gap-2 transition-colors"
        >
          <Plus size={20} />
          <span>محصول جدید</span>
        </button>
      </div>

      {/* Products Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-right">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-6 py-3 font-bold text-slate-900">نام محصول</th>
              <th className="px-6 py-3 font-bold text-slate-900">قیمت (تومان)</th>
              <th className="px-6 py-3 font-bold text-slate-900">موجودی</th>
              <th className="px-6 py-3 font-bold text-slate-900">عملیات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {products.map((product) => (
              <tr key={product.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4 font-semibold text-slate-900">{product.name}</td>
                <td className="px-6 py-4 text-slate-700">{product.price.toLocaleString("fa-IR")}</td>
                <td className="px-6 py-4">
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-semibold ${
                      product.stock < 50 ? "bg-yellow-100 text-yellow-800" : "bg-green-100 text-green-800"
                    }`}
                  >
                    {product.stock} عدد
                  </span>
                </td>
                <td className="px-6 py-4 flex gap-2">
                  <button
                    onClick={() => handleEdit(product)}
                    className="text-blue-600 hover:text-blue-800 font-semibold"
                  >
                    <Edit2 size={18} />
                  </button>
                  <button
                    onClick={() => handleDelete(product.id)}
                    className="text-red-600 hover:text-red-800 font-semibold"
                  >
                    <Trash2 size={18} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Edit/Add Modal */}
      {(editing || isAdding) && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-lg p-8 w-full max-w-md">
            <h3 className="text-2xl font-bold text-primary mb-6 text-right">
              {editing ? "ویرایش محصول" : "افزودن محصول جدید"}
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-right text-slate-700 font-semibold mb-2">نام محصول</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                />
              </div>

              <div>
                <label className="block text-right text-slate-700 font-semibold mb-2">قیمت (تومان)</label>
                <input
                  type="number"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                />
              </div>

              <div>
                <label className="block text-right text-slate-700 font-semibold mb-2">موجودی</label>
                <input
                  type="number"
                  value={formData.stock}
                  onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                />
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={handleSave}
                className="flex-1 bg-primary hover:bg-primary/90 text-white font-bold py-2 px-4 rounded-lg transition-colors"
              >
                ذخیره
              </button>
              <button
                onClick={() => {
                  setEditing(null)
                  setIsAdding(false)
                }}
                className="flex-1 bg-slate-300 hover:bg-slate-400 text-slate-900 font-bold py-2 px-4 rounded-lg transition-colors"
              >
                لغو
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
