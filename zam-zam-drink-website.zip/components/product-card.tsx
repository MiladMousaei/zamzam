"use client"

import Link from "next/link"
import { ShoppingCart } from "lucide-react"

interface Product {
  id: number
  name: string
  description: string
  price: number
  originalPrice: number
  image: string
  stock: number
  category: string
  color: string
}

interface ProductCardProps {
  product: Product
  isLoggedIn: boolean
}

export function ProductCard({ product, isLoggedIn }: ProductCardProps) {
  const discount = Math.round((1 - product.price / product.originalPrice) * 100)

  const colorBg =
    {
      red: "from-red-50 to-red-100",
      orange: "from-orange-50 to-orange-100",
      green: "from-green-50 to-green-100",
    }[product.color] || "from-slate-50 to-slate-100"

  const colorAccent =
    {
      red: "text-red-600",
      orange: "text-orange-600",
      green: "text-green-600",
    }[product.color] || "text-slate-600"

  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow border border-slate-200">
      {/* Image Container */}
      <div className={`bg-gradient-to-b ${colorBg} h-64 flex items-center justify-center overflow-hidden relative`}>
        <img src={product.image || "/placeholder.svg"} alt={product.name} className="w-full h-full object-cover" />
        {discount > 0 && (
          <div className="absolute top-4 right-4 bg-red-500 text-white px-3 py-1 rounded-full font-bold text-sm">
            {discount}%
          </div>
        )}
        {product.stock < 50 && product.stock > 0 && (
          <div className="absolute bottom-4 right-4 bg-yellow-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
            موجودی محدود
          </div>
        )}
        {product.stock === 0 && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <span className="text-white font-bold text-xl">تمام شد</span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-5">
        <h3 className="text-lg font-bold text-slate-900 mb-2 text-right">{product.name}</h3>
        <p className="text-slate-600 text-sm mb-4 text-right line-clamp-2">{product.description}</p>

        {/* Stock Info */}
        <div className="text-sm text-slate-600 mb-4 text-right">
          <span>موجودی: </span>
          <span className={`font-semibold ${colorAccent}`}>{product.stock} عدد</span>
        </div>

        {/* Price */}
        <div className="flex items-center justify-end gap-3 mb-4">
          <div className="text-right">
            <div className="text-2xl font-bold text-primary">{product.price.toLocaleString("fa-IR")} تومان</div>
            {product.originalPrice > product.price && (
              <div className="text-sm text-slate-500 line-through">
                {product.originalPrice.toLocaleString("fa-IR")} تومان
              </div>
            )}
          </div>
        </div>

        {/* Button */}
        {isLoggedIn ? (
          <Link
            href={`/checkout?product=${product.id}`}
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
          >
            <ShoppingCart size={20} />
            <span>افزودن به سفارش</span>
          </Link>
        ) : (
          <Link
            href="/register"
            className="w-full bg-slate-300 hover:bg-slate-400 text-slate-900 font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
          >
            <User size={20} />
            <span>ثبت‌نام برای خرید</span>
          </Link>
        )}
      </div>
    </div>
  )
}

import { User } from "lucide-react"
