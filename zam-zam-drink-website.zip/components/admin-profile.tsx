"use client"

import { useState } from "react"
import { User, Mail, Phone, MapPin, Lock, Edit2, Save, X } from "lucide-react"

interface AdminProfileProps {
  admin: any
}

export function AdminProfile({ admin }: AdminProfileProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState(() => {
    const saved = localStorage.getItem("adminProfile")
    return saved
      ? JSON.parse(saved)
      : {
          name: "مدیر سیستم",
          email: "admin@zamzam.ir",
          phone: "09123456789",
          address: "تهران، ایران",
        }
  })
  const [credentials, setCredentials] = useState(() => {
    const saved = localStorage.getItem("adminCredentials")
    return saved ? JSON.parse(saved) : { username: "admin", password: "admin123" }
  })
  const [showPassword, setShowPassword] = useState(false)

  const handleSave = () => {
    localStorage.setItem("adminProfile", JSON.stringify(formData))
    localStorage.setItem("adminCredentials", JSON.stringify(credentials))
    setIsEditing(false)
  }

  const handleChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleCredentialChange = (field: string, value: string) => {
    setCredentials({ ...credentials, [field]: value })
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 border border-slate-200">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-900">اطلاعات مدیر</h2>
        {!isEditing && (
          <button
            onClick={() => setIsEditing(true)}
            className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg transition-colors"
          >
            <Edit2 size={18} />
            <span>ویرایش</span>
          </button>
        )}
      </div>

      {!isEditing ? (
        <div className="space-y-4">
          <div className="flex items-center gap-4 pb-4 border-b border-slate-200">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
              <User size={32} className="text-primary" />
            </div>
            <div>
              <p className="text-sm text-slate-600">نام مدیر</p>
              <p className="text-xl font-bold text-slate-900">{formData.name}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg">
              <Mail size={20} className="text-primary mt-1" />
              <div>
                <p className="text-sm text-slate-600">ایمیل</p>
                <p className="text-slate-900 font-semibold">{formData.email}</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg">
              <Phone size={20} className="text-primary mt-1" />
              <div>
                <p className="text-sm text-slate-600">شماره تماس</p>
                <p className="text-slate-900 font-semibold" dir="ltr">
                  {formData.phone}
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg">
            <MapPin size={20} className="text-primary mt-1" />
            <div>
              <p className="text-sm text-slate-600">آدرس</p>
              <p className="text-slate-900 font-semibold">{formData.address}</p>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 space-y-3">
            <h3 className="font-bold text-slate-900 text-right">اطلاعات ورود</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg">
                <User size={20} className="text-primary mt-1" />
                <div>
                  <p className="text-sm text-slate-600">نام کاربری</p>
                  <p className="text-slate-900 font-semibold">{credentials.username}</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg">
                <Lock size={20} className="text-primary mt-1" />
                <div>
                  <p className="text-sm text-slate-600">رمز عبور</p>
                  <p className="text-slate-900 font-semibold">
                    {showPassword ? credentials.password : "•".repeat(credentials.password.length)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <form className="space-y-4">
          <h3 className="font-bold text-slate-900 text-right border-b pb-3">اطلاعات شخصی</h3>

          <div>
            <label className="block text-right text-slate-700 font-semibold mb-2">نام</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
            />
          </div>

          <div>
            <label className="block text-right text-slate-700 font-semibold mb-2">ایمیل</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => handleChange("email", e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
            />
          </div>

          <div>
            <label className="block text-right text-slate-700 font-semibold mb-2">شماره تماس</label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => handleChange("phone", e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
            />
          </div>

          <div>
            <label className="block text-right text-slate-700 font-semibold mb-2">آدرس</label>
            <textarea
              value={formData.address}
              onChange={(e) => handleChange("address", e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
              rows={3}
            />
          </div>

          <div className="pt-4 border-t">
            <h3 className="font-bold text-slate-900 text-right border-b pb-3 mb-4">تغیر اطلاعات ورود</h3>

            <div>
              <label className="block text-right text-slate-700 font-semibold mb-2">نام کاربری</label>
              <input
                type="text"
                value={credentials.username}
                onChange={(e) => handleCredentialChange("username", e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
              />
            </div>

            <div>
              <label className="block text-right text-slate-700 font-semibold mb-2 mt-3">رمز عبور</label>
              <input
                type="password"
                value={credentials.password}
                onChange={(e) => handleCredentialChange("password", e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                autoComplete="new-password"
              />
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={handleSave}
              className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors font-semibold"
            >
              <Save size={18} />
              <span>ذخیره</span>
            </button>
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="flex-1 flex items-center justify-center gap-2 bg-slate-300 hover:bg-slate-400 text-slate-900 px-4 py-2 rounded-lg transition-colors font-semibold"
            >
              <X size={18} />
              <span>لغو</span>
            </button>
          </div>
        </form>
      )}
    </div>
  )
}
