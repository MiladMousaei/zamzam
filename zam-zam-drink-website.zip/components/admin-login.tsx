"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"

interface AdminLoginProps {
  onLoginSuccess: (adminData: any) => void
}

export function AdminLogin({ onLoginSuccess }: AdminLoginProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    // Get credentials from localStorage or use defaults
    const savedAdmin = localStorage.getItem("adminCredentials")
    const adminCreds = savedAdmin ? JSON.parse(savedAdmin) : { username: "admin", password: "admin123" }

    if (username === adminCreds.username && password === adminCreds.password) {
      const adminData = { username, loginTime: new Date().toLocaleDateString("fa-IR") }
      localStorage.setItem("admin", JSON.stringify(adminData))
      onLoginSuccess(adminData)
    } else {
      setError("نام کاربری یا رمز عبور نادرست است")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-white rounded-lg shadow-lg p-8 border border-slate-200">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-primary mb-2">پنل مدیریت زمزم</h1>
          <p className="text-slate-600">ورود مدیر</p>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-right">{error}</div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-right text-slate-700 font-semibold mb-2">نام کاربری</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
              placeholder="نام کاربری"
              autoComplete="off"
            />
          </div>

          <div>
            <label className="block text-right text-slate-700 font-semibold mb-2">رمز عبور</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
              placeholder="رمز عبور"
              autoComplete="off"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 px-4 rounded-lg transition-colors mt-6"
          >
            ورود
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-slate-200">
          <Link
            href="/"
            className="text-center block text-slate-600 hover:text-primary transition-colors font-semibold"
          >
            بازگشت به صفحه اصلی
          </Link>
        </div>
      </div>
    </div>
  )
}
