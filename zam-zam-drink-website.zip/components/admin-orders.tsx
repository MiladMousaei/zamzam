"use client"

import { useState, useEffect } from "react"
import { Trash2, Eye } from "lucide-react"

interface Order {
  id: number
  customerId: number
  customerName: string
  customerPhone: string
  customerAddress: string
  items: any[]
  total: number
  notes: string
  status: string
  createdAt: string
  createdTime: string
}

export function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>([])
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [filterStatus, setFilterStatus] = useState("all")

  useEffect(() => {
    const savedOrders = JSON.parse(localStorage.getItem("orders") || "[]")
    setOrders(savedOrders)
  }, [])

  const handleStatusChange = (orderId: number, newStatus: string) => {
    const updated = orders.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order))
    setOrders(updated)
    localStorage.setItem("orders", JSON.stringify(updated))
  }

  const handleDeleteOrder = (orderId: number) => {
    if (confirm("آیا از حذف سفارش اطمینان دارید؟")) {
      const updated = orders.filter((order) => order.id !== orderId)
      setOrders(updated)
      localStorage.setItem("orders", JSON.stringify(updated))
      setSelectedOrder(null)
    }
  }

  const filteredOrders = filterStatus === "all" ? orders : orders.filter((order) => order.status === filterStatus)

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Orders List */}
      <div className="lg:col-span-2">
        <div className="bg-white rounded-lg shadow border border-slate-200 overflow-hidden">
          {/* Filter */}
          <div className="p-4 border-b border-slate-200 flex gap-2">
            {["all", "pending", "processing", "completed", "cancelled"].map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                  filterStatus === status ? "bg-primary text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                {status === "all" && "همه"}
                {status === "pending" && "در انتظار"}
                {status === "processing" && "در حال انجام"}
                {status === "completed" && "تکمیل شده"}
                {status === "cancelled" && "لغو شده"}
              </button>
            ))}
          </div>

          {/* Orders */}
          <div className="overflow-x-auto">
            <table className="w-full text-right">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-3 font-bold text-slate-900">شناسه</th>
                  <th className="px-6 py-3 font-bold text-slate-900">مشتری</th>
                  <th className="px-6 py-3 font-bold text-slate-900">موارد</th>
                  <th className="px-6 py-3 font-bold text-slate-900">مجموع</th>
                  <th className="px-6 py-3 font-bold text-slate-900">تاریخ</th>
                  <th className="px-6 py-3 font-bold text-slate-900">وضعیت</th>
                  <th className="px-6 py-3 font-bold text-slate-900">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-8 text-center text-slate-500">
                      سفارشی یافت نشد
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-semibold text-slate-900">{order.id}</td>
                      <td className="px-6 py-4 text-slate-700">{order.customerName}</td>
                      <td className="px-6 py-4 text-slate-700">{order.items.length} مورد</td>
                      <td className="px-6 py-4 font-bold text-primary">{order.total.toLocaleString("fa-IR")} تومان</td>
                      <td className="px-6 py-4 text-slate-700">{order.createdAt}</td>
                      <td className="px-6 py-4">
                        <select
                          value={order.status}
                          onChange={(e) => handleStatusChange(order.id, e.target.value)}
                          className="px-3 py-1 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary"
                        >
                          <option value="pending">در انتظار</option>
                          <option value="processing">در حال انجام</option>
                          <option value="completed">تکمیل شده</option>
                          <option value="cancelled">لغو شده</option>
                        </select>
                      </td>
                      <td className="px-6 py-4 flex gap-2">
                        <button onClick={() => setSelectedOrder(order)} className="text-blue-600 hover:text-blue-800">
                          <Eye size={18} />
                        </button>
                        <button onClick={() => handleDeleteOrder(order.id)} className="text-red-600 hover:text-red-800">
                          <Trash2 size={18} />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Order Details */}
      {selectedOrder && (
        <div className="bg-white rounded-lg shadow border border-slate-200 p-6 h-fit">
          <h3 className="text-xl font-bold text-primary mb-4 text-right">تفاصیل سفارش</h3>

          <div className="space-y-4 text-right">
            <div>
              <p className="text-slate-600 text-sm">شناسه سفارش</p>
              <p className="font-bold text-slate-900">{selectedOrder.id}</p>
            </div>

            <div className="border-t border-slate-200 pt-4">
              <p className="text-slate-600 text-sm font-semibold mb-2">اطلاعات مشتری</p>
              <p className="font-semibold text-slate-900">{selectedOrder.customerName}</p>
              <p className="text-sm text-slate-600">{selectedOrder.customerPhone}</p>
              <p className="text-sm text-slate-600">{selectedOrder.customerAddress}</p>
            </div>

            <div className="border-t border-slate-200 pt-4">
              <p className="text-slate-600 text-sm font-semibold mb-2">موارد سفارش</p>
              <div className="space-y-2">
                {selectedOrder.items.map((item, idx) => (
                  <div key={idx} className="text-sm">
                    <p className="font-semibold text-slate-900">{item.name}</p>
                    <p className="text-slate-600">
                      {item.quantity} عدد × {item.price.toLocaleString("fa-IR")} تومان
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-slate-200 pt-4">
              <p className="text-slate-600 text-sm">مجموع</p>
              <p className="text-2xl font-bold text-primary">{selectedOrder.total.toLocaleString("fa-IR")} تومان</p>
            </div>

            {selectedOrder.notes && (
              <div className="border-t border-slate-200 pt-4">
                <p className="text-slate-600 text-sm font-semibold mb-2">یادداشت‌ها</p>
                <p className="text-slate-700 text-sm">{selectedOrder.notes}</p>
              </div>
            )}
          </div>

          <button
            onClick={() => setSelectedOrder(null)}
            className="w-full mt-6 bg-slate-200 hover:bg-slate-300 text-slate-900 font-bold py-2 px-4 rounded-lg transition-colors"
          >
            بستن
          </button>
        </div>
      )}
    </div>
  )
}
