"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Navigation } from "@/components/navigation"

export default function RegisterPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    password: "",
    confirmPassword: "",
  })
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    // Validation
    if (!formData.name || !formData.email || !formData.phone || !formData.address) {
      setError("لطفاً تمام فیلدها را پر کنید")
      return
    }

    if (formData.password !== formData.confirmPassword) {
      setError("رمز عبور منطبق نیست")
      return
    }

    if (formData.password.length < 6) {
      setError("رمز عبور باید حداقل 6 کاراکتر باشد")
      return
    }

    // Save customer
    const customer = {
      id: Date.now(),
      ...formData,
      registeredAt: new Date().toLocaleDateString("fa-IR"),
    }

    localStorage.setItem("customer", JSON.stringify(customer))
    localStorage.setItem(
      "customers",
      JSON.stringify([...JSON.parse(localStorage.getItem("customers") || "[]"), customer]),
    )

    setSuccess("ثبت‌نام با موفقیت انجام شد!")
    setTimeout(() => {
      router.push("/")
    }, 1500)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Navigation customer={null} onLogout={() => {}} />

      <div className="max-w-md mx-auto py-12 px-4">
        <div className="bg-white rounded-lg shadow-lg p-8 border border-slate-200">
          <h1 className="text-3xl font-bold text-center text-primary mb-2">ثبت‌نام در زمزم</h1>
          <p className="text-center text-slate-600 mb-8">مشتری جدید می‌باشید؟ ثبت‌نام کنید</p>

          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-right">
              {error}
            </div>
          )}

          {success && (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 text-right">
              {success}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Name */}
            <div>
              <label className="block text-right text-slate-700 font-semibold mb-2">نام و نام‌خانوادگی</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                placeholder="نام شما"
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-right text-slate-700 font-semibold mb-2">ایمیل</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                placeholder="ایمیل شما"
              />
            </div>

            {/* Phone */}
            <div>
              <label className="block text-right text-slate-700 font-semibold mb-2">شماره تماس</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                placeholder="09XX XXX XXXX"
              />
            </div>

            {/* City */}
            <div>
              <label className="block text-right text-slate-700 font-semibold mb-2">شهر</label>
              <input
                type="text"
                name="city"
                value={formData.city}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                placeholder="شهر خود را وارد کنید"
              />
            </div>

            {/* Address */}
            <div>
              <label className="block text-right text-slate-700 font-semibold mb-2">آدرس</label>
              <input
                type="text"
                name="address"
                value={formData.address}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                placeholder="آدرس تحویل"
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-right text-slate-700 font-semibold mb-2">رمز عبور</label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                placeholder="رمز عبور"
              />
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-right text-slate-700 font-semibold mb-2">تأیید رمز عبور</label>
              <input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                placeholder="تأیید رمز عبور"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 px-4 rounded-lg transition-colors mt-6"
            >
              ثبت‌نام
            </button>
          </form>

          <p className="text-center text-slate-600 mt-6">
            قبلاً ثبت‌نام کرده‌اید؟{" "}
            <Link href="/" className="text-primary font-semibold hover:underline">
              بازگشت
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
