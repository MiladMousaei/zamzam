"use client"

import { useState, useEffect } from "react"
import { Menu, X, LogOut, Home, Package, ShoppingBag, User } from "lucide-react"
import { AdminLogin } from "@/components/admin-login"
import { AdminOrders } from "@/components/admin-orders"
import { AdminProducts } from "@/components/admin-products"
import { AdminProfile } from "@/components/admin-profile"

type AdminTab = "dashboard" | "orders" | "products" | "profile"

export default function AdminPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [admin, setAdmin] = useState(null)
  const [currentTab, setCurrentTab] = useState<AdminTab>("dashboard")
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if admin is logged in
    const savedAdmin = localStorage.getItem("admin")
    if (savedAdmin) {
      setIsLoggedIn(true)
      setAdmin(JSON.parse(savedAdmin))
    }
    setLoading(false)
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("admin")
    setIsLoggedIn(false)
    setAdmin(null)
    setCurrentTab("dashboard")
  }

  if (loading) return <div className="flex items-center justify-center min-h-screen">درحال بارگذاری...</div>

  if (!isLoggedIn) {
    return (
      <AdminLogin
        onLoginSuccess={(adminData) => {
          setAdmin(adminData)
          setIsLoggedIn(true)
        }}
      />
    )
  }

  return (
    <div className="min-h-screen bg-slate-100 flex">
      {/* Sidebar */}
      <aside
        className={`${sidebarOpen ? "block" : "hidden"} md:block w-64 bg-slate-900 text-white fixed md:relative h-screen z-40 overflow-y-auto`}
      >
        <div className="p-6">
          <h1 className="text-2xl font-bold">زمزم</h1>
          <p className="text-slate-400 text-sm">پنل مدیریت</p>
        </div>

        <nav className="space-y-2 px-4">
          <button
            onClick={() => {
              setCurrentTab("dashboard")
              setSidebarOpen(false)
            }}
            className={`w-full text-right px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${
              currentTab === "dashboard" ? "bg-primary text-white" : "text-slate-300 hover:bg-slate-800"
            }`}
          >
            <Home size={20} />
            <span>داشبورد</span>
          </button>

          <button
            onClick={() => {
              setCurrentTab("orders")
              setSidebarOpen(false)
            }}
            className={`w-full text-right px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${
              currentTab === "orders" ? "bg-primary text-white" : "text-slate-300 hover:bg-slate-800"
            }`}
          >
            <ShoppingBag size={20} />
            <span>سفارش‌ها</span>
          </button>

          <button
            onClick={() => {
              setCurrentTab("products")
              setSidebarOpen(false)
            }}
            className={`w-full text-right px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${
              currentTab === "products" ? "bg-primary text-white" : "text-slate-300 hover:bg-slate-800"
            }`}
          >
            <Package size={20} />
            <span>محصولات</span>
          </button>

          <button
            onClick={() => {
              setCurrentTab("profile")
              setSidebarOpen(false)
            }}
            className={`w-full text-right px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${
              currentTab === "profile" ? "bg-primary text-white" : "text-slate-300 hover:bg-slate-800"
            }`}
          >
            <User size={20} />
            <span>اطلاعات مدیر</span>
          </button>
        </nav>

        <div className="absolute bottom-4 left-4 right-4">
          <button
            onClick={handleLogout}
            className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
          >
            <LogOut size={20} />
            <span>خروج</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 min-h-screen">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-slate-200">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center gap-4">
              <button onClick={() => setSidebarOpen(!sidebarOpen)} className="md:hidden text-slate-700">
                {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
              <h2 className="text-2xl font-bold text-slate-900">
                {currentTab === "dashboard" && "داشبورد"}
                {currentTab === "orders" && "مدیریت سفارش‌ها"}
                {currentTab === "products" && "مدیریت محصولات"}
                {currentTab === "profile" && "اطلاعات مدیر"}
              </h2>
            </div>
            <div className="text-right">
              <p className="text-slate-600">مدیر: {(admin as any)?.username}</p>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="p-6">
          {currentTab === "dashboard" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Stats */}
              <StatCard
                title="کل سفارش‌ها"
                value={JSON.parse(localStorage.getItem("orders") || "[]").length}
                color="bg-blue-500"
              />
              <StatCard
                title="مجموع درآمد"
                value={`${Math.round(JSON.parse(localStorage.getItem("orders") || "[]").reduce((sum: number, o: any) => sum + o.total, 0) / 1000)}هزار`}
                color="bg-green-500"
              />
              <StatCard
                title="مشتریان"
                value={JSON.parse(localStorage.getItem("customers") || "[]").length}
                color="bg-orange-500"
              />
            </div>
          )}

          {currentTab === "orders" && <AdminOrders />}
          {currentTab === "products" && <AdminProducts />}
          {currentTab === "profile" && <AdminProfile admin={admin} />}
        </main>
      </div>
    </div>
  )
}

function StatCard({ title, value, color }: { title: string; value: any; color: string }) {
  return (
    <div className="bg-white rounded-lg shadow p-6 border border-slate-200">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-slate-600 font-semibold text-right">{title}</p>
          <p className={`text-3xl font-bold mt-2 ${color.replace("bg-", "text-")}`}>{value}</p>
        </div>
        <div className={`${color} w-16 h-16 rounded-lg opacity-20`} />
      </div>
    </div>
  )
}
