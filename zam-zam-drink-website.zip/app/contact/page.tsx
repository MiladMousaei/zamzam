"use client"

import type React from "react"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { Mail, Phone, MapPin, Clock } from "lucide-react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  })
  const [success, setSuccess] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSuccess("پیام شما با موفقیت ارسال شد. به زودی با شما تماس گرفته خواهد شد.")
    setFormData({ name: "", email: "", phone: "", message: "" })
    setTimeout(() => setSuccess(""), 5000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Navigation customer={null} onLogout={() => {}} />

      {/* Hero Section */}
      <section className="w-full bg-gradient-to-r from-primary to-accent text-white py-12 md:py-16">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">تماس با ما</h1>
          <p className="text-lg text-white/90">ما اینجا هستیم تا شنوایم و کمک کنیم</p>
        </div>
      </section>

      {/* Contact Info Section */}
      <section className="w-full py-12 md:py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <div className="bg-slate-50 p-6 rounded-lg border border-slate-200 text-center">
              <Phone className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-bold text-lg mb-2">تماس تلفنی</h3>
              <p className="text-slate-600">021-1234-5678</p>
            </div>
            <div className="bg-slate-50 p-6 rounded-lg border border-slate-200 text-center">
              <Mail className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-bold text-lg mb-2">ایمیل</h3>
              <p className="text-slate-600">info@zamzam.ir</p>
            </div>
            <div className="bg-slate-50 p-6 rounded-lg border border-slate-200 text-center">
              <MapPin className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-bold text-lg mb-2">آدرس</h3>
              <p className="text-slate-600">تهران، خیابان آزادی</p>
            </div>
            <div className="bg-slate-50 p-6 rounded-lg border border-slate-200 text-center">
              <Clock className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-bold text-lg mb-2">ساعات کاری</h3>
              <p className="text-slate-600">شنبه تا چهارشنبه 9-17</p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="max-w-2xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">فرم تماس</h2>

            {success && (
              <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6 text-right">
                {success}
              </div>
            )}

            <form onSubmit={handleSubmit} className="bg-white border border-slate-200 rounded-lg p-8 shadow-lg">
              <div className="mb-6">
                <label className="block text-right text-slate-700 font-semibold mb-2">نام</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                  placeholder="نام شما"
                />
              </div>

              <div className="mb-6">
                <label className="block text-right text-slate-700 font-semibold mb-2">ایمیل</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                  placeholder="ایمیل شما"
                />
              </div>

              <div className="mb-6">
                <label className="block text-right text-slate-700 font-semibold mb-2">شماره تماس</label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right"
                  placeholder="شماره تماس"
                />
              </div>

              <div className="mb-6">
                <label className="block text-right text-slate-700 font-semibold mb-2">پیام</label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right resize-none"
                  placeholder="پیام شما"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 px-4 rounded-lg transition-colors"
              >
                ارسال پیام
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  )
}
