"use client"

import Link from "next/link"
import { useState, useEffect } from "react"
import { ProductCard } from "@/components/product-card"
import { Navigation } from "@/components/navigation"

export default function HomePage() {
  const [products, setProducts] = useState([])
  const [customer, setCustomer] = useState(null)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    // Initialize products data
    const initialProducts = [
      {
        id: 1,
        name: "نوشابه گازدار کولا",
        description: "نوشابه گازدار کولا زمزم با طعم تازه و مطبوع",
        price: 15000,
        originalPrice: 18000,
        image: "/images/img-20251130-014843.jpg",
        stock: 150,
        category: "نوشابه",
        color: "red",
      },
      {
        id: 2,
        name: "نوشابه گازدار پرتقالی",
        description: "نوشابه گازدار پرتقالی زمزم با طعم میوه طبیعی",
        price: 15000,
        originalPrice: 18000,
        image: "/images/img-20251130-014843.jpg",
        stock: 120,
        category: "نوشابه",
        color: "orange",
      },
      {
        id: 3,
        name: "نوشابه گازدار لیمو زمزم",
        description: "نوشابه گازدار لیمو زمزم با طعم تازگی و شیرینی",
        price: 15000,
        originalPrice: 18000,
        image: "/images/img-20251130-014843.jpg",
        stock: 140,
        category: "نوشابه",
        color: "green",
      },
    ]

    setProducts(initialProducts)

    // Check for logged-in customer
    const savedCustomer = localStorage.getItem("customer")
    if (savedCustomer) {
      setCustomer(JSON.parse(savedCustomer))
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("customer")
    setCustomer(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Navigation customer={customer} onLogout={handleLogout} />

      {/* Hero Section */}
      <section className="w-full bg-gradient-to-r from-red-500 via-orange-500 to-green-500 text-white py-16 md:py-24">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center gap-8">
          <div className="flex-1 text-right">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance">خوشمزه‌ترین نوشیدنی‌ها با برند زمزم</h1>
            <p className="text-lg md:text-xl mb-8 text-white/90">
              تجربه طعم بی‌نظیر نوشابه‌های گازدار زمزم با کیفیت بالا و تازگی تضمین‌شده
            </p>
            <Link
              href="#products"
              className="inline-block bg-white text-primary font-bold py-3 px-8 rounded-lg hover:bg-slate-100 transition-colors"
            >
              خرید کنید
            </Link>
          </div>
          <div className="flex-1">
            <img src="/images/img-20251130-014843.jpg" alt="محصولات زمزم" className="w-full max-w-sm object-contain" />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="w-full py-12 md:py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-primary">چرا زمزم انتخاب کنید؟</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: "کیفیت بالا", desc: "تمام محصولات با استانداردهای بین‌المللی تولید می‌شوند" },
              { title: "طعم تازه", desc: "طعم طبیعی و بدون اضافات مضر برای سلامت شما" },
              { title: "قیمت مناسب", desc: "بهترین قیمت برای محصولات با کیفیت فوق‌العاده" },
            ].map((item, idx) => (
              <div key={idx} className="bg-slate-50 p-8 rounded-lg border border-slate-200 text-center">
                <h3 className="text-xl font-bold text-primary mb-3">{item.title}</h3>
                <p className="text-slate-700">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="w-full py-16 md:py-20 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-primary">محصولات شرکت زمزم</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} isLoggedIn={!!customer} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-16 bg-primary text-white">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">آماده برای سفارش؟</h2>
          <p className="text-lg mb-8 text-white/90">ثبت‌نام کنید و از تخفیف‌های ویژه بهره‌مند شوید</p>
          {customer ? (
            <Link
              href="/checkout"
              className="inline-block bg-white text-primary font-bold py-3 px-8 rounded-lg hover:bg-slate-100 transition-colors"
            >
              ادامه خرید
            </Link>
          ) : (
            <Link
              href="/register"
              className="inline-block bg-white text-primary font-bold py-3 px-8 rounded-lg hover:bg-slate-100 transition-colors"
            >
              ثبت‌نام و خرید
            </Link>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full bg-slate-900 text-white py-12">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8 pb-8 border-b border-slate-700">
            <div>
              <h3 className="text-xl font-bold mb-4">درباره زمزم</h3>
              <p className="text-slate-400">
                شرکت زمزم متخصص در تولید و فروش نوشیدنی‌های گازدار با کیفیت بالا و طعم بی‌نظیر است.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">لینک‌های سریع</h3>
              <ul className="space-y-2 text-slate-400">
                <li>
                  <Link href="/" className="hover:text-primary transition-colors">
                    خانه
                  </Link>
                </li>
                <li>
                  <Link href="/#products" className="hover:text-primary transition-colors">
                    محصولات
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-primary transition-colors">
                    تماس با ما
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">اطلاعات مدیریت</h3>
              <div className="text-slate-400 space-y-2">
                <p>
                  <strong>مدیر سایت:</strong> علی احمدی
                </p>
                <p>
                  <strong>ایمیل:</strong> admin@zamzam.ir
                </p>
                <p>
                  <strong>تلفن:</strong> 021-1234-5678
                </p>
                <p>
                  <strong>آدرس:</strong> تهران، خیابان آزادی
                </p>
              </div>
            </div>
          </div>
          <p className="text-center text-slate-400">تمام حقوق محفوظ است © ۱۴۰۴ شرکت زمزم</p>
        </div>
      </footer>
    </div>
  )
}
