"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { Navigation } from "@/components/navigation"
import { Trash2, Plus, Minus } from "lucide-react"

interface CartItem {
  productId: number
  name: string
  price: number
  quantity: number
  maxStock: number
}

const PRODUCTS_DATA = [
  {
    id: 1,
    name: "نوشابه گازدار کولا",
    price: 15000,
    maxStock: 150,
  },
  {
    id: 2,
    name: "نوشابه گازدار پرتقالی",
    price: 15000,
    maxStock: 120,
  },
  {
    id: 3,
    name: "نوشابه گازدار لیمو زمزم",
    price: 15000,
    maxStock: 140,
  },
]

export default function CheckoutPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [customer, setCustomer] = useState(null)
  const [cart, setCart] = useState<CartItem[]>([])
  const [loading, setLoading] = useState(true)
  const [orderNotes, setOrderNotes] = useState("")
  const [quantity, setQuantity] = useState<{ [key: number]: number }>({})

  useEffect(() => {
    // Check login status
    const savedCustomer = localStorage.getItem("customer")
    if (!savedCustomer) {
      router.push("/register")
      return
    }
    setCustomer(JSON.parse(savedCustomer))

    // Load cart
    const savedCart = localStorage.getItem("cart")
    if (savedCart) {
      setCart(JSON.parse(savedCart))
    }

    // Load quantities
    const savedQuantities = localStorage.getItem("quantities")
    if (savedQuantities) {
      setQuantity(JSON.parse(savedQuantities))
    }

    // Check if adding product from URL
    const productId = searchParams.get("product")
    if (productId) {
      addToCart(Number.parseInt(productId))
    }

    setLoading(false)
  }, [])

  const addToCart = (productId: number) => {
    const product = PRODUCTS_DATA.find((p) => p.id === productId)
    if (!product) return

    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.productId === productId)
      if (existing) {
        return prevCart
      }
      return [
        ...prevCart,
        {
          productId,
          name: product.name,
          price: product.price,
          quantity: 1,
          maxStock: product.maxStock,
        },
      ]
    })

    setQuantity((prev) => ({
      ...prev,
      [productId]: (prev[productId] || 0) + 1,
    }))
  }

  const updateQuantity = (productId: number, delta: number) => {
    const newQty = (quantity[productId] || 1) + delta

    if (newQty < 1) {
      removeFromCart(productId)
      return
    }

    const product = PRODUCTS_DATA.find((p) => p.id === productId)
    if (product && newQty > product.maxStock) {
      alert(`حداکثر موجودی: ${product.maxStock} عدد`)
      return
    }

    setQuantity((prev) => ({
      ...prev,
      [productId]: newQty,
    }))
  }

  const removeFromCart = (productId: number) => {
    setCart((prevCart) => prevCart.filter((item) => item.productId !== productId))
    setQuantity((prev) => {
      const newQty = { ...prev }
      delete newQty[productId]
      return newQty
    })
  }

  const handleAddProduct = (productId: number) => {
    const existing = cart.find((item) => item.productId === productId)
    if (existing) {
      updateQuantity(productId, 1)
    } else {
      addToCart(productId)
    }
  }

  const calculateTotal = () => {
    return cart.reduce((total, item) => {
      return total + item.price * (quantity[item.productId] || 1)
    }, 0)
  }

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault()

    if (cart.length === 0) {
      alert("سبد خرید خالی است")
      return
    }

    // Create order
    const order = {
      id: Date.now(),
      customerId: (customer as any).id,
      customerName: (customer as any).name,
      customerPhone: (customer as any).phone,
      customerAddress: (customer as any).address,
      items: cart.map((item) => ({
        ...item,
        quantity: quantity[item.productId] || 1,
      })),
      total: calculateTotal(),
      notes: orderNotes,
      status: "pending",
      createdAt: new Date().toLocaleDateString("fa-IR"),
      createdTime: new Date().toLocaleTimeString("fa-IR"),
    }

    // Save order
    const orders = JSON.parse(localStorage.getItem("orders") || "[]")
    orders.push(order)
    localStorage.setItem("orders", JSON.stringify(orders))

    // Clear cart
    localStorage.removeItem("cart")
    localStorage.removeItem("quantities")

    alert("سفارش با موفقیت ثبت شد!")
    router.push("/")
  }

  if (loading) return <div>درحال بارگذاری...</div>

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Navigation customer={customer} onLogout={() => router.push("/")} />

      <div className="max-w-6xl mx-auto py-12 px-4">
        <h1 className="text-3xl md:text-4xl font-bold text-primary mb-8 text-center">سبد خرید و سفارش</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Products */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-lg p-6 border border-slate-200 mb-8">
              <h2 className="text-2xl font-bold text-primary mb-6 text-right">محصولات موجود</h2>
              <div className="space-y-4">
                {PRODUCTS_DATA.map((product) => (
                  <div
                    key={product.id}
                    className="border border-slate-200 rounded-lg p-4 flex items-center justify-between"
                  >
                    <div className="flex-1">
                      <h3 className="font-bold text-slate-900 text-right">{product.name}</h3>
                      <p className="text-slate-600 text-right text-sm">موجودی: {product.maxStock} عدد</p>
                      <p className="text-primary font-bold text-lg mt-1 text-right">
                        {product.price.toLocaleString("fa-IR")} تومان
                      </p>
                    </div>
                    <button
                      onClick={() => handleAddProduct(product.id)}
                      className="bg-secondary hover:bg-secondary/90 text-white font-bold py-2 px-6 rounded-lg transition-colors"
                    >
                      افزودن
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Cart Items */}
            {cart.length > 0 && (
              <div className="bg-white rounded-lg shadow-lg p-6 border border-slate-200">
                <h2 className="text-2xl font-bold text-primary mb-6 text-right">سبد خرید</h2>
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div
                      key={item.productId}
                      className="border border-slate-200 rounded-lg p-4 flex items-center justify-between"
                    >
                      <div className="flex-1">
                        <h3 className="font-bold text-slate-900 text-right">{item.name}</h3>
                        <p className="text-slate-600 text-right text-sm">{item.price.toLocaleString("fa-IR")} تومان</p>
                      </div>

                      <div className="flex items-center gap-4">
                        <button
                          onClick={() => removeFromCart(item.productId)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 size={20} />
                        </button>

                        <div className="flex items-center border border-slate-300 rounded-lg">
                          <button
                            onClick={() => updateQuantity(item.productId, -1)}
                            className="px-3 py-1 text-slate-600 hover:text-slate-900"
                          >
                            <Minus size={18} />
                          </button>
                          <span className="px-4 py-1 font-bold text-slate-900">{quantity[item.productId] || 1}</span>
                          <button
                            onClick={() => updateQuantity(item.productId, 1)}
                            className="px-3 py-1 text-slate-600 hover:text-slate-900"
                          >
                            <Plus size={18} />
                          </button>
                        </div>

                        <div className="text-right min-w-32">
                          <p className="font-bold text-primary text-lg">
                            {((quantity[item.productId] || 1) * item.price).toLocaleString("fa-IR")} تومان
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {cart.length === 0 && (
              <div className="bg-slate-50 rounded-lg p-12 text-center border border-slate-200">
                <p className="text-slate-600 text-lg mb-4">سبد خرید شما خالی است</p>
                <Link href="/#products" className="text-primary font-bold hover:underline">
                  برو به محصولات
                </Link>
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div>
            <div className="bg-white rounded-lg shadow-lg p-6 border border-slate-200 sticky top-20">
              <h2 className="text-2xl font-bold text-primary mb-6 text-right">خلاصه سفارش</h2>

              <form onSubmit={handleCheckout} className="space-y-4">
                {/* Customer Info */}
                <div className="bg-slate-50 p-4 rounded-lg text-right">
                  <p className="font-semibold text-slate-900">{(customer as any)?.name}</p>
                  <p className="text-sm text-slate-600">{(customer as any)?.phone}</p>
                  <p className="text-sm text-slate-600">{(customer as any)?.address}</p>
                </div>

                {/* Order Notes */}
                <div>
                  <label className="block text-right font-semibold text-slate-700 mb-2">یادداشت سفارش</label>
                  <textarea
                    value={orderNotes}
                    onChange={(e) => setOrderNotes(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 text-right resize-none"
                    rows={3}
                    placeholder="یادداشت‌های خود را اینجا بنویسید"
                  />
                </div>

                {/* Summary */}
                <div className="border-t-2 border-slate-200 pt-4 space-y-2">
                  <div className="flex justify-between text-right text-slate-600">
                    <span>تعداد کالا:</span>
                    <span>{cart.reduce((sum, item) => sum + (quantity[item.productId] || 1), 0)} عدد</span>
                  </div>
                  <div className="flex justify-between text-right font-bold text-lg text-primary">
                    <span>مجموع:</span>
                    <span>{calculateTotal().toLocaleString("fa-IR")} تومان</span>
                  </div>
                </div>

                {/* Submit */}
                <button
                  type="submit"
                  disabled={cart.length === 0}
                  className="w-full bg-primary hover:bg-primary/90 disabled:bg-slate-300 text-white font-bold py-3 px-4 rounded-lg transition-colors mt-6"
                >
                  ثبت سفارش
                </button>

                <Link
                  href="/"
                  className="block text-center text-slate-600 hover:text-primary transition-colors font-semibold mt-3"
                >
                  بازگشت
                </Link>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
